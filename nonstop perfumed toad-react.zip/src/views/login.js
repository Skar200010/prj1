import React from 'react'

import { Helmet } from 'react-helmet'

import './login.css'

const Login = (props) => {
  return (
    <div className="login-container">
      <Helmet>
        <title>login - Nonstop Perfumed Toad</title>
        <meta property="og:title" content="login - Nonstop Perfumed Toad" />
      </Helmet>
    </div>
  )
}

export default Login
